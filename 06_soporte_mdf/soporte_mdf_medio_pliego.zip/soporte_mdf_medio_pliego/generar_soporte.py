# Soporte MDF 3 mm (v6): medio pliego 700 x 500 mm
import ezdxf, os, json, numpy as np, rectpack
from shapely.geometry import Polygon
from shapely import affinity
P = dict(t=3.0, nlam=2, base_layers=2, gus_lam=2, trav_lam=2,
    H=300.0, Wc=50.0, S=360.0, over=20.0, hb=60.0,
    pin_d=5.2, bolt_d=4.2, clr=0.2,
    zmin=130.0, zmax=270.0, step=10.0,
    baseX=50.0, baseY=200.0, tabW=30.0,                 # base 50 x 200; pestana de columna de 30 mm
    gus_b=70.0, gus_h=75.0, gus_a=23.0, gus_T=23.0,     # escuadras mas pequenas
    sw=16.0, slot_len=200.0, slot_w=4.4,
    cw=50.0, drop=30.0, caja_x=15.625, caja_y=20.625, caja_h=11.0, tube_d=10.6,
    ps_D=40.0, ps_layers=4, logo_h=34.0,
    sheetW=700.0, sheetH=500.0, gap=3.0, margin=5.0)
t=P['t']; ct=P['nlam']*t; sock=P['base_layers']*t; gt=P['gus_lam']*t
Lcol=P['H']+sock; Lx=2*P['over']+2*P['Wc']+P['S']; cx1=P['over']+P['Wc']/2; cx2=Lx-cx1
zs=[P['zmin']+i*P['step'] for i in range(int(round((P['zmax']-P['zmin'])/P['step']))+1)]
LOGO=json.load(open('logo_uniandes_vectores.json'))
def new():
    d=ezdxf.new('R2010'); d.units=ezdxf.units.MM; d.layers.add('CORTE',color=1); d.layers.add('GRABADO',color=5); return d
def poly(m,pts,layer='CORTE'): m.add_lwpolyline(pts,close=True,dxfattribs={'layer':layer})
def rect(m,x,y,w,h,layer='CORTE'): poly(m,[(x,y),(x+w,y),(x+w,y+h),(x,y+h)],layer)
def circ(m,x,y,d): m.add_circle((x,y),d/2,dxfattribs={'layer':'CORTE'})
def slot(m,xc,yc,L,w):
    r=w/2; a=xc-L/2+r; b=xc+L/2-r
    m.add_lwpolyline([(a,yc-r,0),(b,yc-r,1),(b,yc+r,0),(a,yc+r,1)],format='xyb',close=True,dxfattribs={'layer':'CORTE'})
def text(m,s,x,y,h=3.2): m.add_text(s,height=h,dxfattribs={'layer':'GRABADO'}).set_placement((x,y))
def logo(m,ox,oy,h):
    for p in LOGO: poly(m,[(ox+x*h,oy+y*h) for x,y in p],'GRABADO')
def columna(m,ox,oy,grab=False):
    W=P['Wc']; a=(W-P['tabW'])/2
    poly(m,[(ox,oy+sock),(ox+a,oy+sock),(ox+a,oy),(ox+W-a,oy),(ox+W-a,oy+sock),(ox+W,oy+sock),(ox+W,oy+Lcol),(ox,oy+Lcol)])
    for i,z in enumerate(zs):
        circ(m,ox+W/2,oy+sock+z,P['pin_d'])
        if grab:
            m.add_line((ox,oy+sock+z),(ox+(8 if i%5==0 else 5),oy+sock+z),dxfattribs={'layer':'GRABADO'}); text(m,str(i+1),ox+10,oy+sock+z-1.6)
def base(m,ox,oy,sup=False):
    X,Y=P['baseX'],P['baseY']; rect(m,ox,oy,X,Y); cx=ox+X/2; cy=oy+Y/2
    rect(m,cx-(P['tabW']+P['clr'])/2,cy-(ct+P['clr'])/2,P['tabW']+P['clr'],ct+P['clr'])
    for dx in (10,X-10):
        for dy in (10,Y-10): circ(m,ox+dx,oy+dy,4.5)
    if sup:
        off=ct/2+P['gus_a']+P['gus_T']/2
        for s in (+1,-1): rect(m,cx-(gt+P['clr'])/2,cy+s*off-(P['gus_T']+P['clr'])/2,gt+P['clr'],P['gus_T']+P['clr'])
def esc_pts():
    a,T,b,h=P['gus_a'],P['gus_T'],P['gus_b'],P['gus_h']
    return [(0,t),(a,t),(a,0),(a+T,0),(a+T,t),(b,t),(0,t+h)]
def escuadra(m,ox,oy): poly(m,[(ox+x,oy+y) for x,y in esc_pts()])
# par de escuadras encajadas por la diagonal (para el acomodo)
_P1=Polygon(esc_pts()); _P2=affinity.rotate(_P1,180,origin=(0,0)); _n=np.array([P['gus_h'],P['gus_b']])/np.hypot(P['gus_h'],P['gus_b'])
for _s in np.arange(0,40,0.25):
    _X=P['gus_b']+_n[0]*_s; _Y=P['gus_h']+2*t+_n[1]*_s
    if _P1.distance(affinity.translate(_P2,_X,_Y))>=P['gap']: break
PAR_W,PAR_H=_P1.union(affinity.translate(_P2,_X,_Y)).bounds[2:]
def par_escuadras(m,ox,oy):
    escuadra(m,ox,oy); poly(m,[(ox-x+_X,oy-y+_Y) for x,y in esc_pts()])
def vline(m,x,y0,y1): m.add_line((x,y0),(x,y1),dxfattribs={'layer':'GRABADO'})
def marca_vertical(m,x,oy):   # linea grabada de lado a lado, interrumpida en la ranura
    r=P['slot_w']/2+1.0
    vline(m,x,oy+2,oy+P['hb']/2-r); vline(m,x,oy+P['hb']/2+r,oy+P['hb']-2)
def travesano(m,ox,oy,marcas=None):
    rect(m,ox,oy,Lx,P['hb'])
    if marcas in ('frente','atras'): marca_vertical(m,ox+Lx/2,oy)                 # centro
    if marcas=='frente':
        for s in (-1,1): marca_vertical(m,ox+Lx/2+s*P['cw']/2,oy)                # bordes del carro centrado
    for cx in (cx1,cx2):
        circ(m,ox+cx,oy+P['hb']/2,P['pin_d'])
        for s in (+1,-1):
            xs=cx+s*(P['Wc']/2+0.5+P['sw']/2)
            for yy in (15,P['hb']-15): circ(m,ox+xs,oy+yy,P['bolt_d'])
    for xs in (Lx/2-130,Lx/2+130):
        for yy in (15,P['hb']-15): circ(m,ox+xs,oy+yy,P['bolt_d'])
    slot(m,ox+Lx/2,oy+P['hb']/2,P['slot_len'],P['slot_w'])
def separador(m,ox,oy):
    rect(m,ox,oy,P['sw'],P['hb'])
    for yy in (15,P['hb']-15): circ(m,ox+P['sw']/2,oy+yy,P['bolt_d'])
TABX=(P['cw']/2-14,P['cw']/2+14); TABW=10.0
def carro_placa(m,ox,oy):   # placa vertical del carro, con el escudo grabado al frente
    W=P['cw']; rect(m,ox,oy,W,P['hb']+P['drop'])
    yb=P['drop']+P['hb']/2
    for x in (W/2-15,W/2+15): circ(m,ox+x,oy+yb,P['bolt_d'])
    hps=P['ps_layers']*t
    for x in TABX: rect(m,ox+x-(TABW+P['clr'])/2,oy+5,TABW+P['clr'],hps+P['clr'])
    h=P['logo_h']; w=h*max(x for p in LOGO for x,y in p)
    y_lo=5+hps+P['clr']+1.5; y_hi=yb-4.5-1.0          # entre las ranuras y las arandelas de los tornillos
    logo(m,ox+(W-w)/2,oy+y_lo+((y_hi-y_lo)-h)/2,h)
def ps_capa(m,ox,oy,fondo):
    W,D=P['cw'],P['ps_D']; pts=[(0,0)]
    for x in TABX: pts+=[(x-TABW/2,0),(x-TABW/2,-t),(x+TABW/2,-t),(x+TABW/2,0)]
    pts+=[(W,0),(W,D),(0,D)]; poly(m,[(ox+x,oy+t+y) for x,y in pts])
    cxx,cyy=ox+W/2,oy+t+D/2
    if fondo: circ(m,cxx,cyy,P['tube_d'])
    else: rect(m,cxx-(P['caja_x']+0.3)/2,cyy-(P['caja_y']+0.3)/2,P['caja_x']+0.3,P['caja_y']+0.3)
    for s in (+1,-1): rect(m,cxx+s*14-2.2,cyy-2,4.4,4.0)
def anillo(m,ox,oy): m.add_circle((ox+7,oy+7),7,dxfattribs={'layer':'CORTE'}); circ(m,ox+7,oy+7,P['bolt_d'])
piezas=[
 ('columna_frontal_grabada', lambda m,x,y: columna(m,x,y,True), P['Wc'],Lcol, 2),
 ('columna_lamina',          lambda m,x,y: columna(m,x,y,False),P['Wc'],Lcol, 2*P['nlam']-2),
 ('base_superior',           lambda m,x,y: base(m,x,y,True),  P['baseX'],P['baseY'], 2),
 ('base_inferior',           lambda m,x,y: base(m,x,y,False), P['baseX'],P['baseY'], 2*P['base_layers']-2),
 ('escuadra',                lambda m,x,y: escuadra(m,x,y),   P['gus_b'],P['gus_h']+t, 4*P['gus_lam']),
 ('travesano_frontal_marcas',lambda m,x,y: travesano(m,x,y,'frente'), Lx,P['hb'], 1),
 ('travesano_trasero_marca', lambda m,x,y: travesano(m,x,y,'atras'),  Lx,P['hb'], 1),
 ('travesano',               lambda m,x,y: travesano(m,x,y),  Lx,P['hb'], 2*P['trav_lam']-2),
 ('separador',               lambda m,x,y: separador(m,x,y),  P['sw'],P['hb'], 6*P['nlam']),
 ('carro_placa_escudo',      lambda m,x,y: carro_placa(m,x,y),P['cw'],P['hb']+P['drop'], 1),
 ('portasensor_fondo',       lambda m,x,y: ps_capa(m,x,y,True),  P['cw'],P['ps_D']+t, 1),
 ('portasensor_marco',       lambda m,x,y: ps_capa(m,x,y,False), P['cw'],P['ps_D']+t, P['ps_layers']-1),
 ('carro_anillo_espaciador', lambda m,x,y: anillo(m,x,y),     14,14, 8),   # 4 se usan + 4 de repuesto
]
os.makedirs('dxf_piezas',exist_ok=True)
for nom,f,w,h,q in piezas:
    d=new(); f(d.modelspace(),0,0); d.saveas(f'dxf_piezas/{nom}.dxf')
# acomodo en el medio pliego (escuadras en pares encajados)
items=[]
for n,f,w,h,q in piezas:
    if n=='escuadra': items+=[('par_escuadras',par_escuadras,PAR_W,PAR_H)]*(q//2)
    else: items+=[(n,f,w,h)]*q
SW,SH,g,mg=P['sheetW'],P['sheetH'],P['gap'],P['margin']
pk=rectpack.newPacker(rotation=True,pack_algo=rectpack.MaxRectsBssf,sort_algo=rectpack.SORT_AREA)
for i,(n,f,w,h) in enumerate(items): pk.add_rect(w+g,h+g,rid=i)
pk.add_bin(SW-2*mg+g,SH-2*mg+g); pk.pack()
placed=pk.rect_list()
assert len(placed)==len(items), f"NO CABE: {len(placed)}/{len(items)}"
d=new(); m=d.modelspace(); rect(m,0,0,SW,SH,'GRABADO')
for b,x,y,w,h,rid in placed:
    n,f,w0,h0=items[rid]; x+=mg; y+=mg; blk=d.blocks.new(name=f'P{rid}'); f(blk,0,0)
    rot=abs((w-g)-w0)>0.01
    m.add_blockref(f'P{rid}',(x+h0,y) if rot else (x,y),dxfattribs={'rotation':90 if rot else 0}).explode()
d.saveas('medio_pliego_700x500.dxf')
used=max(y+h for b,x,y,w,h,rid in placed)+mg; usedx=max(x+w for b,x,y,w,h,rid in placed)+mg
area=sum(w*h for n,f,w,h,q in piezas for _ in range(q))/1e6
json.dump(dict(P,Lx=Lx,Lcol=Lcol,ct=ct,sock=sock,huecos={i+1:z for i,z in enumerate(zs)},piezas=sum(q for *_,q in piezas),area_m2=area,
  cantidades={n:q for n,f,w,h,q in piezas},par=(PAR_W,PAR_H)),open('parametros.json','w'),indent=1)
print(f"CABE: {len(placed)} bloques ({sum(q for *_,q in piezas)} piezas) en {SW:.0f}x{SH:.0f} | area piezas {area:.3f} m2 = {100*area/(SW*SH/1e6):.0f}% de la lamina | travesano {Lx:.0f} mm | par escuadras {PAR_W:.0f}x{PAR_H:.0f}")
