import cadquery as cq, json, ezdxf, itertools
from shapely.geometry import Polygon as SPoly
P=json.load(open('parametros.json'))
t=P['t']; ct=P['ct']; sock=P['sock']; Wc=P['Wc']; Lx=P['Lx']; hb=P['hb']; dr=P['drop']; cw=P['cw']
gt=P['gus_lam']*t; tl=P['trav_lam']*t; Lcol=P['Lcol']; tabW=P['tabW']
cxs=[P['over']+Wc/2, Lx-P['over']-Wc/2]
HUECO=8; zc=sock+P['huecos'][str(HUECO)]; gap=ct/2+0.5
def box(x0,x1,y0,y1,z0,z1): return cq.Workplane('XY').box(x1-x0,y1-y0,z1-z0,centered=False).translate((x0,y0,z0))
def cylY(x,z,d,y0,y1): return cq.Workplane('XZ').circle(d/2).extrude(-(y1-y0)).translate((x,y0,z))
def cylZ(x,y,d,z0,z1): return cq.Workplane('XY').circle(d/2).extrude(z1-z0).translate((x,y,z0))
A=cq.Assembly(name='soporte_sensor_IR')
MDF=cq.Color(0.80,0.66,0.47); MDF2=cq.Color(0.69,0.54,0.36); MDF3=cq.Color(0.48,0.35,0.20)
for i,cx in enumerate(cxs,1):
    col=box(cx-Wc/2,cx+Wc/2,-ct/2,ct/2,sock,Lcol).union(box(cx-tabW/2,cx+tabW/2,-ct/2,ct/2,0,sock))
    for z in P['huecos'].values(): col=col.cut(cylY(cx,sock+z,P['pin_d'],-ct,ct))
    A.add(col,name=f'columna_{i}',color=MDF)
    A.add(box(cx-P['baseX']/2,cx+P['baseX']/2,-P['baseY']/2,P['baseY']/2,0,sock).cut(box(cx-tabW/2,cx+tabW/2,-ct/2,ct/2,0,sock)),name=f'base_{i}',color=MDF2)
    for s,nm in ((-1,'adelante'),(1,'atras')):
        tri=cq.Workplane('YZ').polyline([(s*ct/2,sock),(s*(ct/2+P['gus_b']),sock),(s*ct/2,sock+P['gus_h'])]).close().extrude(gt).translate((cx-gt/2,0,0))
        A.add(tri,name=f'escuadra_{i}_{nm}',color=MDF)
    A.add(cylY(cx,zc,5.0,-gap-tl-6,gap+tl+6),name=f'pasador_M5_{i}',color=cq.Color(0.94,0.62,0.15))
for s,nm in ((-1,'frontal'),(1,'trasera')):
    y0,y1=(-gap-tl,-gap) if s<0 else (gap,gap+tl)
    pl=box(0,Lx,y0,y1,zc-hb/2,zc+hb/2)
    for cx in cxs: pl=pl.cut(cylY(cx,zc,P['pin_d'],y0-1,y1+1))
    pl=pl.cut(box(Lx/2-P['slot_len']/2,Lx/2+P['slot_len']/2,y0-1,y1+1,zc-P['slot_w']/2,zc+P['slot_w']/2))
    yface=y0 if s<0 else y1; d=0.4*(1 if s<0 else -1)
    xs_m=[Lx/2] + ([Lx/2-cw/2,Lx/2+cw/2] if s<0 else [])
    for xm in xs_m:
        for za,zb in ((zc-hb/2+2,zc-P['slot_w']/2-1),(zc+P['slot_w']/2+1,zc+hb/2-2)):
            pl=pl.cut(box(xm-0.3,xm+0.3,min(yface,yface+d),max(yface,yface+d),za,zb))
    A.add(pl,name=f'travesano_{nm}',color=MDF2)
xs_sep=[cx+s*(Wc/2+0.5+P['sw']/2) for cx in cxs for s in (-1,1)]+[Lx/2-130,Lx/2+130]
for k,xs in enumerate(xs_sep,1):
    A.add(box(xs-P['sw']/2,xs+P['sw']/2,-gap,gap,zc-hb/2,zc+hb/2),name=f'pila_separadores_{k}',color=MDF3)
yp1=-gap-tl; yp0=yp1-t; zpl=zc-hb/2-dr
placa=box(Lx/2-cw/2,Lx/2+cw/2,yp0,yp1,zpl,zc+hb/2)
# escudo grabado 0.4 mm en la cara frontal de la placa del carro
lg=[e for e in ezdxf.readfile('dxf_piezas/carro_placa_escudo.dxf').modelspace() if e.dxf.layer=='GRABADO' and e.dxftype()=='LWPOLYLINE']
esc=None
for e in lg:
    pts=list(SPoly([(Lx/2-cw/2+p[0],zpl+p[1]) for p in e.get_points()]).buffer(0).exterior.coords)[:-1]
    s_=cq.Workplane('XZ').polyline(pts).close().extrude(0.4); bb=s_.val().BoundingBox(); s_=s_.translate((0,yp0-bb.ymin,0))
    esc=s_ if esc is None else esc.union(s_)
A.add(placa.cut(esc),name='carro_placa',color=MDF)
A.add(esc,name='grabado_escudo_uniandes',color=cq.Color(0.25,0.15,0.05))
for dx in (-15,15):
    lado="izq" if dx<0 else "der"
    A.add(cylY(Lx/2+dx,zc,4.0,yp0-6,gap+tl+8),name=f'tornillo_carro_M4_{lado}',color=cq.Color(0.4,0.4,0.4))
    A.add(cylY(Lx/2+dx,zc,14.0,-gap,gap),name=f'anillos_{lado}',color=cq.Color(0.94,0.62,0.15))
zps=zpl+5; D=P['ps_D']; yc=yp1+D/2
ps=box(Lx/2-cw/2,Lx/2+cw/2,yp1,yp1+D,zps,zps+P['ps_layers']*t)
ps=ps.cut(box(Lx/2-(P['caja_x']+0.3)/2,Lx/2+(P['caja_x']+0.3)/2,yc-(P['caja_y']+0.3)/2,yc+(P['caja_y']+0.3)/2,zps+t,zps+P['ps_layers']*t+1))
ps=ps.cut(cylZ(Lx/2,yc,P['tube_d'],zps-1,zps+t+1))
A.add(ps,name='portasensor',color=MDF3)
A.add(box(Lx/2-P['caja_x']/2,Lx/2+P['caja_x']/2,yc-P['caja_y']/2,yc+P['caja_y']/2,zps+t,zps+t+P['caja_h']),name='caja_ABS_sensor',color=cq.Color(0.35,0.35,0.35))
A.add(cylZ(Lx/2,yc,10.1,zps+t-40,zps+t),name='telescopio_40mm',color=cq.Color(0.2,0.2,0.2))
A.add(box(Lx/2-150,Lx/2+150,-150,150,0,1),name='lamina_30x30_referencia',color=cq.Color(0.36,0.79,0.65))
A.export('ensamble_soporte.step')
bb=A.toCompound().BoundingBox()
print("STEP ok. %.0f x %.0f x %.0f mm | hueco %d | punta del telescopio a %.0f mm de la lamina"%(bb.xlen,bb.ylen,bb.zlen,HUECO,zps+t-40-1))
sol={c.name:c.obj.val() for c in A.children}
bad=[]
for a,b in itertools.combinations(sol,2):
    if any(k in a+b for k in ('tornillo','anillos','pasador','grabado')): continue
    try:
        v=sol[a].intersect(sol[b]).Volume()
        if v>1.0: bad.append((a,b,round(v)))
    except Exception: pass
print("interferencias:",bad if bad else "ninguna")
g=sol['grabado_escudo_uniandes'].BoundingBox(); print("escudo en placa: x %.1f-%.1f (centro %.1f, travesano centro %.1f), z %.1f-%.1f"%(g.xmin,g.xmax,(g.xmin+g.xmax)/2,Lx/2,g.zmin,g.zmax))
